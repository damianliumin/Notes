#include <klib.h>

void printf_test();
void memory_test();

int main() {
  printf("Test start!\n");
  printf_test();
  memory_test();
  printf("Test end!\n");
  return 0;
}
