#include <amtest.h>

void mp_print() {
  while (1) {
    printf("%d", _cpu());
  }
}
