#include <amdev.h>

#define MKK(k) _KEY_##k
#define MKK_COUNT 256
