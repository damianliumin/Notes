/*
 * spinlock
 * debug sign: 1-5
 * 
 */

#include <common.h>

void spin_init(spinlock_t *lk, const char *name) {
  lk->locked = 0;
  lk->name   = name;
  lk->cpu    = -1;
}

inline bool holding_spinlock(spinlock_t *lk){  // must be called in os_trap
  Assert(ienabled() == false, 4, "call hold_splk with interrupt\n");
  return lk->cpu == cpu_current();
}

void spin_lock(spinlock_t *lk) {
  bool i = ienabled();
  iset(false);
  if(cpu_task[cpu_current()].num_lock == 0)
    cpu_task[cpu_current()].init_ienable = i;
  Assert(!holding_spinlock(lk), 1, "AA dead lock\n");  

  while (atomic_xchg((int*)&lk->locked, 1)) ; // fence
  __sync_synchronize();

  Assert(lk->cpu == -1, 2,  "lock conflict\n");
  cpu_task[cpu_current()].num_lock ++;
  lk->cpu = cpu_current();
}

void spin_unlock(spinlock_t *lk) {
  Assert(lk->cpu == cpu_current(), 3, "lock stolen\n");
  lk->cpu = -1;

  __sync_synchronize();
  atomic_xchg((int*)&lk->locked, 0);

  cpu_task[cpu_current()].num_lock --;
  if(cpu_task[cpu_current()].num_lock == 0
  && cpu_task[cpu_current()].init_ienable)
    iset(true);
}
