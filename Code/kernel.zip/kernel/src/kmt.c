/*
 * kmt
 * debug sign: 11-20
 * 
 */

#include <common.h>
#define current (cpu_task[cpu_current()].cur_task)

cpu_info cpu_task[CPU_NUM] = {0};
task_t cpu_idle[CPU_NUM] = {0};
task_t *task_list_cur = NULL;
spinlock_t task_list_lock;

static inline void check_canary(task_t* task){
  Assert(*(uint32_t*)task->stack == CANARY && 
  *(uint32_t*)(task->stack + STACK_SIZE - 4) == CANARY,
   11, "canary check fail\n");
}

static inline void set_canary(task_t* task){
  *(uint32_t*)task->stack = CANARY;
  *(uint32_t*)(task->stack + STACK_SIZE - 4) = CANARY;
}

static int kmt_create(task_t *task, const char *name, void (*entry)(void *arg), void *arg) {
  // basic init
  memset(task, 0, sizeof(task_t));
  task->status = SLEEP;
  task->stack  = pmm->alloc(STACK_SIZE);
  set_canary(task);
  Area area = {task->stack, task->stack + STACK_SIZE - 32};
  task->context = kcontext(area, entry, arg);
  task->name = name;
  task->sem_next = NULL;
  task->cpu = -1;
  // add to task list
  spin_lock(&task_list_lock);
  if(task_list_cur == NULL){
    task_list_cur = task;
    task->next = task->prev = task;
  } else {
    task->next = task_list_cur->next;
    task->prev = task_list_cur;
    task->next->prev = task;
    task->prev->next = task;
  }
  spin_unlock(&task_list_lock);
  return 0;
}

static void kmt_teardown(task_t *task) {
  spin_lock(&task_list_lock);             // =====> task list lock
  if(task->next == task){
    assert(task_list_cur == task);
    task_list_cur = NULL;
  } else {
    if(task_list_cur == task)
      task_list_cur = task->next;
    task->next->prev = task->prev;
    task->prev->next = task->next;
  }
  switch(task->status){
    case RUN: case PROT:  task->status = KILLED;  break;
    case SLEEP:           pmm->free(task->stack); break;
    default:  Assert(0, 15, "tear down status error\n");
  }
  spin_unlock(&task_list_lock);           // <===== task list lock
}

static task_t *get_task(){
  spin_lock(&task_list_lock);             // =====> task list lock
  task_t *ret = NULL;
  task_t *rec = task_list_cur;

  if(task_list_cur != NULL){
    do {
      if(task_list_cur->status == SLEEP && task_list_cur->cpu == -1
      && task_list_cur != cpu_task[cpu_current()].prev_task){  // caution!
        ret = task_list_cur;
        ret->status = RUN;
        ret->cpu = cpu_current();
        task_list_cur = task_list_cur->next;
        break;
      }
      task_list_cur = task_list_cur->next;  
    } while(task_list_cur != rec);
  }

  spin_unlock(&task_list_lock);           // <===== task list lock
  return ret;
}

static Context* kmt_context_save(Event ev, Context *context){
  if(current != &cpu_idle[cpu_current()]) check_canary(current);
  spin_lock(&task_list_lock);             // =====> task list lock
  // set current task
  current->context = context;
  Assert(current->cpu == cpu_current(), 12, "kmt error!\n");
  current->cpu = -1;
  current->cpu_wait = (cpu_current() + 1) % cpu_count();
  switch(current->status){
    case RUN:   current->status = PROT; break;
    case BLOCK: case SIG:               break;
    case KILLED:                        break;
    default:    Assert(0, 13, "cur state error\n");
  }
  // set prev task (this mechanism is to avoid data race on stack)
  task_t *prev = cpu_task[cpu_current()].prev_task;
  if(prev && prev != current){
    switch(prev->status){
      case PROT:  prev->status = SLEEP;       break;
      case BLOCK: prev->status = PROT_BLOCK;  break;
      case SIG:   prev->status = SLEEP;       break;
      case KILLED:pmm->free(prev->stack);     break;
      default: Assert(0, 14, "prev state error\n");
    }
  }
  spin_unlock(&task_list_lock);           // <===== task list lock
  assert(ienabled() == false);
  return NULL;
}

static Context* kmt_schedule(Event ev, Context *context){
  task_t *to = get_task();
  assert(ienabled() == false);
  if(to == NULL){
    to = &cpu_idle[cpu_current()];
    to->status = RUN;
    to->cpu = cpu_current();
  } else 
    check_canary(to);
  
  cpu_task[cpu_current()].prev_task = current;
  current = to;
  return to->context;
}

static Context* kmt_error(Event ev, Context *context){
  return NULL;
}

static void kmt_init(){
  for(int i = 0 ;i < cpu_count() ;++i){
    cpu_task[i].cur_task  = &cpu_idle[i];
    cpu_task[i].prev_task = NULL;
    cpu_idle[i].name      = "idle";
    cpu_idle[i].next      = cpu_idle[i].prev = NULL;
    cpu_idle[i].status    = RUN;
    cpu_idle[i].context   = NULL;
    cpu_idle[i].stack     = NULL;
    cpu_idle[i].cpu       = i;
    cpu_idle[i].cpu_wait  = i;
  }

  spin_init(&task_list_lock, "task list lock");
  os->on_irq(INT_MIN,     EVENT_NULL,   kmt_context_save);   // first call
  os->on_irq(INT_MIN + 1, EVENT_ERROR,  kmt_error);
  os->on_irq(INT_MAX,     EVENT_NULL,   kmt_schedule);       // last call
}

MODULE_DEF(kmt) = {
  .init         = kmt_init,
  .create       = kmt_create,  // not on irq
  .teardown     = kmt_teardown,  // not on irq
  .spin_init    = spin_init,
  .spin_lock    = spin_lock,  // on irq
  .spin_unlock  = spin_unlock,  // on irq
  .sem_init     = sem_init,
  .sem_wait     = sem_wait,  // not on irq
  .sem_signal   = sem_signal,  // on irq
};

