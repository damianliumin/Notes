#include <common.h>

#ifndef SAFE_PMM

static bool pmm_inited = false;

static void *heap_start, *heap_end;
static int SLAB_NUM = 0;
static kheap_slab_t slab_manager[MAX_SLAB_NUM];
static spinlock_t slab_lock;

static int SLOW_SLAB_NUM = 0;
static kheap_slow_t slow_slab_manager[MAX_SLOW_SLAB_NUM];
static spinlock_t slow_slab_lock;

static kheap_fast_t fast_slab_manager[CPU_NUM];
static page_t *free_page = NULL;
static spinlock_t fast_page_lock;

static inline int size2idx(size_t size){
  size >>= 4;
  int ret = 0;
  while(size){
    size >>= 1;
    ret ++;
  }
  return ret;
}

static inline int first_zero_bit(uint32_t data){
  data = ~data;
  assert(data);
	int pos=0;
	if ((data & 0xFFFF) == 0)	data >>= 16, pos += 16;
	if ((data & 0xFF) == 0) data >>= 8, pos += 8;
	if ((data & 0xF) == 0) data >>= 4, pos += 4;
	if ((data & 0x3) == 0) data >>= 2,	pos += 2;
	if ((data & 0x1) == 0) pos += 1;
	return pos;
}

static inline size_t allign_size(size_t size){
  size_t ret = 1;
  while(ret < size)
    ret <<= 1;
  return ret;
}

/* slab manager */
static int alloc_slab(int id){ // 1 if fast, 2 if slow
  spin_lock(&slab_lock);                      // =====> slab lock
  int i = 0;
  for(;i < SLAB_NUM ;++i)
    if(slab_manager[i].used == 0){
      slab_manager[i].used = id; break;
    }
  if(i == SLAB_NUM) i = -1;
  spin_unlock(&slab_lock);                    // <===== slab lock
  return i;
}

static int fast_new_slab(){
  assert(free_page == NULL);
  int id = alloc_slab(FAST);
  if(id == -1) return -1;
  free_page = slab_manager[id].start;         
  page_t* tmp = free_page;
  while(tmp < (page_t*)((char*)free_page + SLAB_SIZE)){
    spin_init(&tmp->lock, "cpu fp lock");
    if(tmp > free_page) tmp->prev = tmp - 1;
    if(tmp + 1 < (page_t*)((char*)free_page + SLAB_SIZE)) tmp->next = tmp + 1;
    tmp += 1;
  }
  (tmp - 1)->next = NULL;
  return 1;
}

static int slow_new_slab(int cpu){
  int id = alloc_slab(SLOW);
  if(id == -1) return -1;
  spin_lock(&slow_slab_lock);                 // =====> slow slab lock
  ++ SLOW_SLAB_NUM;
  slow_slab_manager[SLOW_SLAB_NUM - 1].start = slab_manager[id].start;
  #ifdef TEST
  memset(slow_slab_manager[SLOW_SLAB_NUM - 1].start, 0, SLOW_SLAB_SIZE);
  memset(&slow_slab_manager[SLOW_SLAB_NUM - 1].map, 0, sizeof(slow_slab_manager[SLOW_SLAB_NUM - 1].map));
  #endif
  spin_init(&slow_slab_manager[SLOW_SLAB_NUM - 1].lock, "slow slab manager lock");
  slow_slab_manager[SLOW_SLAB_NUM - 1].valid = 1;
  slow_slab_manager[SLOW_SLAB_NUM - 1].cpu = cpu;
  int ret = SLOW_SLAB_NUM - 1;
  spin_unlock(&slow_slab_lock);               // <===== slow slab lock
  return ret;
}

/* page manager */
static page_t* alloc_fast_page(size_t size, int cpu){
  spin_lock(&fast_page_lock);                 // =====> fast page lock
  if(free_page == NULL)
    fast_new_slab();
  if(free_page){
    page_t *ret = free_page;
    spin_lock(&ret->lock);  // caution here!  // =====> page lock
    spin_unlock(&ret->lock);                  // <===== page lock
    free_page = free_page->next;  
    spin_unlock(&fast_page_lock);             // <===== fast page lock
    /* init new page */
    memset((void*)ret, 0, HDR_SIZE);
    spin_init(&ret->lock, "cpu fp lock");
    ret->cpu = cpu;
    ret->obj_size = size;
    ret->obj_cnt = 0;
    ret->next = ret->prev = NULL;
    if(size <= 256)
      ret->obj_start = (void*)ret->data;
    else
      ret->obj_start = (void*)((char*)ret + size);
    ret->bit_num = ((uintptr_t)(ret + 1) - (uintptr_t)ret->obj_start) / size;
    if(ret->bit_num > 50 * 32)
      ret->bit_num = 50 * 32;
    return ret;
  } else {
    spin_unlock(&fast_page_lock);             // <===== fast page lock
    return NULL;
  }
}

static void free_fast_page(page_t *page){
  if(page->prev == NULL)
    fast_slab_manager[page->cpu].head[size2idx(page->obj_size)] = page->next;
  else
    page->prev->next = page->next;
  if(page->next != NULL)
    page->next->prev = page->prev;
  page->next = free_page;
  page->prev = NULL;
  if(free_page) free_page->prev = page;
  free_page = page;
}

/* fast path */
static void* fast_alloc(size_t size, int cpu){
  page_t* cur_page = fast_slab_manager[cpu].head[size2idx(size)];
  while(cur_page != NULL){
    spin_lock(&cur_page->lock);               // =====> page lock
    if(cur_page->obj_cnt < cur_page->bit_num)
      for(int i = 0 ;i < (cur_page->bit_num + 31) / 32 ;++i){
        if(cur_page->bitmap[i] == FULL) continue;
        int t = first_zero_bit(cur_page->bitmap[i]);
        if(i * 32 + t + 1 > cur_page->bit_num) break;
        cur_page->bitmap[i] |= (1 << t);
        cur_page->obj_cnt ++;
        spin_unlock(&cur_page->lock);         // <===== page lock
        return (char*)cur_page->obj_start + (i * 32 + t) * size;
      }
    else {
      spin_unlock(&cur_page->lock);           // <===== page lock
      cur_page = cur_page->next;
    }
  }
  return NULL;
}

static void fast_free(void* ptr){
  page_t *page = (page_t*)((char*)ptr - (uintptr_t)ptr % PAGE_SIZE);
  spin_lock(&page->lock);                     // =====> page lock
  int cpu = page->cpu;
  int free = 0;
  int idx = (int)((char*)ptr - (char*)page->obj_start) / page->obj_size;
  int i = idx / 32;
  if(page->bitmap[i] & (1 << (idx % 32))){
    page->bitmap[i] &= ~(1 << (idx % 32));
    page->obj_cnt --;
    if(page->obj_cnt == 0) free = 1;
  }
  spin_unlock(&page->lock);                   // <===== page lock
  if(free){
    spin_lock(&fast_slab_manager[cpu].lock);  // =====> fast slab manager lock
    spin_lock(&fast_page_lock);               // =====> fast page lock
    spin_lock(&page->lock);                   // =====> page lock
    if(page->obj_cnt == 0)
      free_fast_page(page);
    spin_unlock(&page->lock);                 // <===== page lock
    spin_unlock(&fast_page_lock);             // <===== fast page lock
    spin_unlock(&fast_slab_manager[cpu].lock);// <===== fast slab manager lock
  }
}

/* slow path */
static void* slow_alloc(size_t size, int id){
  spin_lock(&slow_slab_manager[id].lock);     // =====> slow slab manager lock
  char* start = slow_slab_manager[id].start;
  assert(slow_slab_manager[id].valid);
  int map_cnt = size / (32 KB);
  for(int i = 0 ;i < SLOW_SLAB_SIZE / PAGE_SIZE ;i += MAX(map_cnt, slow_slab_manager[id].map[i])){
    int valid = 1;
    for(int j = i ;j < i + map_cnt ; ++j)
      if(slow_slab_manager[id].map[j]){
        valid = 0;
        break;
      }
    if(!valid) continue;
    slow_slab_manager[id].map[i] = map_cnt;
    spin_unlock(&slow_slab_manager[id].lock); // <===== slow slab manager lock
    return start + i * (32 KB);
  }
  spin_unlock(&slow_slab_manager[id].lock);   // <===== slow slab manager lock
  return NULL;
}

static void slow_free(void* ptr, int id){
  spin_lock(&slow_slab_manager[id].lock);     // =====> slow slab manager lock
  int start_idx = (int)((char*)ptr - (char*)slow_slab_manager[id].start) / PAGE_SIZE;
  slow_slab_manager[id].map[start_idx] = 0;
  spin_unlock(&slow_slab_manager[id].lock);   // <===== slow slab manager lock
}

/* kalloc, kfree, pmm_init */
static void *kalloc(size_t size) {
  panic_on(!pmm_inited, "pmm not initialized");
  if (size > 16 MB) return NULL;
  size = MAX(allign_size(size), 8);
  int cpu = cpu_current();
  if (size <= 16 KB){  // fast path
    spin_lock(&fast_slab_manager[cpu].lock);  // =====> fast slab manager lock 
    void* ret = fast_alloc(size, cpu);
    if(!ret) {
      page_t* new_page = alloc_fast_page(size, cpu);
      if(new_page == NULL) return NULL;
      page_t* head = fast_slab_manager[cpu].head[size2idx(size)];
      new_page->next = head;
      if(head) head->prev = new_page;
      fast_slab_manager[cpu].head[size2idx(size)] = new_page;
      ret = fast_alloc(size, cpu);
      assert(ret);
    }
    spin_unlock(&fast_slab_manager[cpu].lock);// <===== fast slab manager lock
    return ret;
  } else{  // slow path
    int id = rand() % MAX_SLOW_SLAB_NUM;
    for(int i = 0 ;i < MAX_SLOW_SLAB_NUM ;++i)
      if(slow_slab_manager[(id + i) % MAX_SLOW_SLAB_NUM].valid 
        && slow_slab_manager[(id + i) % MAX_SLOW_SLAB_NUM].cpu == cpu){
        void *ret = slow_alloc(size, (id + i) % MAX_SLOW_SLAB_NUM);
        if(ret) return ret;
      }
    int new_slab_id = slow_new_slab(cpu);
    if(new_slab_id != -1){ 
      void *ret = slow_alloc(size, new_slab_id);
      assert(ret);
      return ret;
    }
    return NULL;
  }  
}

static void kfree(void *ptr) {
  panic_on(!pmm_inited, "pmm not initialized");
  if((char*)ptr < (char*)heap_start || (char*)ptr >= (char*)heap_end) return;
  int id = ((uintptr_t)ptr - (uintptr_t)ptr % SLAB_SIZE - (uintptr_t)heap_start) / SLAB_SIZE;
  int status = slab_manager[id].used;
  if(status == FAST){
    fast_free(ptr);
  } else if (status == SLOW) {
    for(int i = 0 ;i < MAX_SLOW_SLAB_NUM ;++i)
      if(slab_manager[id].start == slow_slab_manager[i].start){
        slow_free(ptr, i);
        return;
      }
    assert(0);
  }
}

static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);
  /* allign heap size */
  if((uintptr_t)heap.start % SLAB_SIZE != 0)
    heap_start = (void*)((uintptr_t)heap.start + SLAB_SIZE - (uintptr_t)heap.start % (SLAB_SIZE));
  heap_end = (void*)((uintptr_t)heap.end - (uintptr_t)heap.end % (SLAB_SIZE));
  /* init slab */
  spin_init(&slab_lock, "slab lock");
  SLAB_NUM = ((char*)heap_end - (char*)heap_start) / SLAB_SIZE;
  assert(SLAB_NUM <= MAX_SLAB_NUM);
  for(int i = 0 ;i < SLAB_NUM ;++i)
    slab_manager[i].start = (void*)((char*)heap_start + i * SLAB_SIZE);
  assert(SLAB_NUM >= 2);
  /* init fast & slow page */
  spin_init(&slow_slab_lock, "slow slab lock");
  spin_init(&fast_page_lock, "fast page lock");
  for(int i = 0 ;i < MAX_SLOW_SLAB_NUM ;++i)
    spin_init(&slow_slab_manager[i].lock, "slow slab manager lock");
  for(int i = 0 ;i < CPU_NUM ;++i)
    spin_init(&fast_slab_manager[i].lock, "fast slab manager lock");
  pmm_inited = true;
}

#else

spinlock_t pmm_lock;
void *cur = NULL;

static inline size_t allign_size(size_t size){
  size_t ret = 1;
  while(ret < size)
    ret <<= 1;
  return ret;
}

static void *kalloc(size_t size){
  spin_lock(&pmm_lock);                       // =====> pmm lock
  size = allign_size(size);
  if((intptr_t)cur % size != 0)
    cur = (char*)cur + (size - (intptr_t)cur % size);
  void *ret = cur;
  cur += size;
  // Log("[%p, %p)\n", ret, ret+size)
  spin_unlock(&pmm_lock);                     // <===== pmm lock
  return ret;
}

static void kfree(void *ptr){
}

static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);
  spin_init(&pmm_lock, "pmm lock");
  cur = heap.start;
}

#endif

static void *kalloc_safe(size_t size) {
  bool i = ienabled();
  iset(false);
  void *ret = kalloc(size);
  if (i) iset(true);
  return ret;
}

static void kfree_safe(void *ptr) {
  int i = ienabled();
  iset(false);
  kfree(ptr);
  if (i) iset(true);
}

MODULE_DEF(pmm) = {
  .init  = pmm_init,
  .alloc = kalloc_safe,
  .free  = kfree_safe,
};
