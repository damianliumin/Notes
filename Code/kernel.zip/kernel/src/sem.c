/*
 * semaphore
 * debug sign: 6-10
 * 
 */

#include <common.h>

#define current (cpu_task[cpu_current()].cur_task)
extern spinlock_t task_list_lock;
extern task_t *task_list_cur;

void sem_init(sem_t *sem, const char *name, int value) {
    sem->name   = name;
    sem->count  = value;
    sem->wait_head.sem_next = NULL;
    spin_init(&sem->sem_lock, name);
}

void sem_wait(sem_t *sem) {  // P
    spin_lock(&sem->sem_lock);                // =====> sem lock
    sem->count --;
    Assert(current->status == RUN, 6, "sem wait task not running\n");
    int success = 1;
    if(sem->count < 0){
        success = 0;
        spin_lock(&task_list_lock);           // =====> task list lock
        current->status = BLOCK;
        spin_unlock(&task_list_lock);         // <===== task list lock
        current->sem_next = NULL;
        task_t *cur = &sem->wait_head;
        while(cur->sem_next != NULL)
            cur = cur->sem_next;
        cur->sem_next = current;
    }
    spin_unlock(&sem->sem_lock);              // <===== sem lock
    if(!success) {    
        yield();
    }
}

void sem_signal(sem_t *sem) {  // V
    spin_lock(&sem->sem_lock);                // =====> sem lock
    sem->count ++;
    if(sem->wait_head.sem_next){
        task_t *cur = sem->wait_head.sem_next;
        sem->wait_head.sem_next = sem->wait_head.sem_next->sem_next;
        spin_lock(&task_list_lock);           // =====> task list lock
        switch(cur->status){
            case BLOCK: 
                cur->status = SIG; 
                break;
            case PROT_BLOCK: 
                cur->status = SLEEP; 
                task_list_cur = cur;
                break;
            default: assert(0);
        }
        spin_unlock(&task_list_lock);         // <===== task list lock
    }
    spin_unlock(&sem->sem_lock);              // <===== sem lock
}


