# Fix16

Ported from [libfixmath](https://code.google.com/p/libfixmath)

The copyright belongs to the original authors (Ben Brewer).

## Use

`#include <fix16.h>`
