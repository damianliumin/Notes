#ifndef __NANOS_H__
#define __NANOS_H__

// Types
typedef intptr_t ssize_t;
typedef intptr_t off_t;
typedef int32_t pid_t;

#endif
